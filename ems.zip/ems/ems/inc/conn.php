<?php 
	$conn = new mysqli('localhost', 'root', '','ems');

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


 ?>