<?php 
    include_once('inc/adm_header.php');

date_default_timezone_set("Asia/Colombo");

$date=getdate(); 
$str_hours= "$date[hours]";
$hours=(int)$str_hours;
$str_min= "$date[minutes]";
$min=(int)$str_min;
$data_tbl=['value ','valuepeek ','valueoffpeek ','valueoffpeekmorning ','day'];
$anlz=['e2','e3','e4','e4','e5','e6','e7','e8','e9','e10','e11','e12','e13','e14'];
$val=0;

$day_time=data_read_query('value',$conn,$anlz,$hours,$min);
$peek_time=data_read_query('valuepeek',$conn,$anlz,$hours,$min);
$off_peek_night_time=data_read_query('valueoffpeek',$conn,$anlz,$hours,$min);
$off_peek_morning_time=data_read_query('valueoffpeekmorning',$conn,$anlz,$hours,$min);
$day_val=data_read_query('day',$conn,$anlz,$hours,$min);
$month=data_read_query('month',$conn,$anlz,$hours,$min);
$off_peek_price=30;
$day_price=70;
$peek_price=90;

function cost($tbl,$conn,$base,$therif)
{
    $units=$cost=0;
     for ($i=0; $i <13 ; $i++) 
    {
        $units+=(int)$tbl["$i"]-(int)$base["$i"];
    }
    $cost=$units*$therif;
    return array($units,$cost);
};
list($off_peek_units,$off_peek_cost)= cost($off_peek_morning_time,$conn,$day_val,$off_peek_price);
list($peek_units,$peek_cost)= cost($peek_time,$conn,$day_time,$peek_price);
list($day_units,$day_cost)= cost($off_peek_morning_time,$conn,$day_val,$day_price);
$total_cost=$day_cost+$off_peek_cost+$peek_cost;
$total_unit=$peek_units+$off_peek_units+$day_units;
function data_read_query($table_name,$conn,$anlz,$hours,$min)
{
        $out=[];
        $query="SELECT * FROM $table_name WHERE _id=(SELECT MAX(_id) FROM $table_name )";
        if (mysqli_query($conn,$query))
        {
            $day_vals=mysqli_fetch_assoc(mysqli_query($conn,$query));
            foreach ($day_vals as  $value)
             {
               
               $out[]= $value;
            }
        }
        else
        {
            echo"error {$table_name}";
        }

        return($out) ;
};

if (  $hours<=5 && $min<=30) 
{
    for ($i=0; $i <13 ; $i++) 
    {
        $val+=(int)$off_peek_morning_time["$i"]-(int)$month["$i"];
    }
}
else if( $hours<=18 && $min<=30)
{
    for ($i=0; $i <13 ; $i++) 
    {
        $val+=(int)$day_time["$i"]-(int)$month["$i"];
    }
}

else if( $hours<=22 && $min<=30)
{
    for ($i=0; $i <13 ; $i++) 
    {
        $val+=(int)$peek_time["$i"]-(int)$month["$i"];
    }
}

else
{
    for ($i=0; $i <13 ; $i++) 
    {
        $val+=(int)$off_peek_night_time["$i"]-(int)$month["$i"];
    }

}


 
?>

    <main>
    <div class="grid_container" >

            <div class="gage_cover grid_items CEB" id="ceb" onclick="data('CEB Total','00','000','0000','000','0000','000')">
                <h1><span style="color: #278bff; font-weight: 20000px;">CEB</span> </h1>
                <div class="gage r">
                      <?php   echo $total_unit; ?>   <b>kW</b>  
                </div>
                <span class="adm_price">RS <?php echo $total_cost; ?> /=</span>
                <br>
              
                <span class="adm_last_update" >last updated <?php   echo $day_val[1]; ?></span>
                <div class="therif_data" id="therif_data">
                   <div class="header"> 
                            <div class="left" id="clk_title"> <h3> CEB Total</h3></div>
                            <div class="right close" id="close" onclick="close_q()"> X</div>
                    </div><!--header-->
                    <br></br>   
                    <div class="data">  
                        <p>     day-time         :<span id="day"><?php echo $day_units; ?></span>    wkh | Rs <span id="day_rs"><?php echo $peek_cost; ?></span> </p>

                        <p>     peek-time        :<span id="peek"> <?php echo $peek_units ;?> </span> kh | Rs <span id="peek_rs"> <?php echo $peek_cost; ?> </span> </p>
                        <p>     off peek-time    :<span id="off_peek"> <?php echo $off_peek_units ?> kh </span>| Rs <span id="off_peek_rs"> <?php echo $off_peek_price; ?> </span></p>
                    </div><!--data-->
                </div><!--therif_data-->
            </div><!--gage cover-->
            <div class="gage_cover grid_items  gen" id="gen">
                <h1><span style="color: #278bff; font-weight: 20000px;">Genarator</span> </h1>
                <div class="gage b">
                    2230 Kw
                </div>
                <span class="adm_price">RS80 000 /=</span>
                <br>
                <span class="adm_last_update">last updated <b><?php    echo $day_val[1]; ?></b></span>                
            </div><!--gage cover-->

            <div class="gage_cover grid_items solar" id="solar">
                <h1><span style="color: #278bff; font-weight: 20000px;">Solar</span> </h1>
                <div class="gage g">
                    2230 Kw
                </div>
                <span class="adm_price">- RS50 000 /=</span>
                <br>
                <span class="adm_last_update">last updated <b><?php    echo $day_val[1]; ?></b></span>                
            </div><!--gage cover-->
        </div><!--grid_container-->

            <div class="button-container" id="button-container">
    <button id="option1" class="option-button">CEB</button>
    <button id="option2" class="option-button">Generator</button>
    <button id="option3" class="option-button">Solar</button>

  </div>
  <script type="text/javascript">
    window.addEventListener("load",function()
        {
            document.getElementById('option1').style.background="red";
            document.getElementById('option2').style.background="#2980b9";
            document.getElementById('option3').style.background="greenyellow";
        }

        );
    
    document.getElementById('option1').addEventListener('click', function() {
  document.getElementById('option1').style.background='red';
  document.getElementById('option2').style.background='#2980b9';
  document.getElementById('option3').style.background='greenyellow';
  document.getElementById('ceb').style.display='block';
  document.getElementById('gen').style.display='none';
  document.getElementById('solar').style.display='none';

});

document.getElementById('option2').addEventListener('click', function() {
  document.getElementById('option2').style.background='red';
  document.getElementById('option1').style.background='#2980b9';
  document.getElementById('option3').style.background='greenyellow';
  alert("s");
  document.getElementById("ceb").style.display='none';
  document.getElementById("gen").style.display='block';
  document.getElementById("solar").style.display='none';

});

document.getElementById('option3').addEventListener('click', function() {
  document.getElementById('option3').style.background='red';
  document.getElementById('option1').style.background='#2980b9 ';
  document.getElementById('option2').style.background='greenyellow';
  document.getElementById('ceb').style.display='none';
  document.getElementById('gen').style.display='none';
  document.getElementById('solar').style.display='block';

});


  </script>
        <div class="grid_container_low" onclick="data('Genaretor Total','0000','000','0000','000','0000','000')">
      
            <div class="gage_cover grid_items stores" onclick="data('CEB','0000','000','0000','000','0000','000')">
                <h1><span style="color: #388bff; font-weight: 20000px;">Stores</span> </h1>
                <div class="gage plt" >
                    <center><b><i>
                        <?php echo $val; ?>
                    </i></b></center>
                </div>
                <span class="adm_price">RS0000 /=</span>
                <br>    
                <span class="adm_last_update">last updated 22/1/2023</span>
            </div><!--gage cover-->
           
            <div class="gage_cover grid_items soap" onclick="data('CEB','0000','000','0000','000','0000','000')">
                <h1><span style="color: #388bff; font-weight: 20000px;">soap</span> </h1>
                <div class="gage plt" >
                    <b><i>
                4256.22 kW
                    </i>
                    </i></b>
                </div>
                    <span class="adm_price">rs 00000 /=</span>
                    <br>
                <spanclass="adm_last_update"> updated  <b>mm/dd/yyyy</b> </span>
            </div><!--gage cover-->

             <div class="gage_cover grid_items complex" onclick="data('CEB','0000','000','0000','000','0000','000')">
                <h1><span style="color: #388bff; font-weight: 20000px;">senap</span> </h1>
                <div class="gage plt" >
                    <b><i>
                4256.22 kW
                    </i>
                    </i></b>
                </div>
                    <span class="adm_price">rs 00000 /=</span>
                    <br>
                <spanclass="adm_last_update"> updated  <b>mm/dd/yyyy</b> </span>
            </div><!--gage cover-->
            <div class="gage_cover grid_items complex" onclick="data('CEB','0000','000','0000','000','0000','000')">
                <h1><span style="color: #388bff; font-weight: 20000px;">PC</span> </h1>
                <div class="gage plt" >
                    <b><i>
                4256.22 kW
                    </i>
                    </i></b>
                </div>
                    <span class="adm_price">rs 00000 /=</span>
                    <br>
                <spanclass="adm_last_update"> updated  <b>mm/dd/yyyy</b> </span>
            </div><!--gage cover--> 

              <div class="gage_cover grid_items complex" onclick="data('CEB','0000','000','0000','000','0000','000')">
                <h1><span style="color: #388bff; font-weight: 20000px;">Complex</span> </h1>
                <div class="gage plt" >
                    <b><i>
                4256.22 kW
                    </i>
                    </i></b>
                </div>
                    <span class="adm_price">rs 00000 /=</span>
                    <br>
                <spanclass="adm_last_update"> updated  <b>mm/dd/yyyy</b> </span>
            </div><!--gage cover-->


        </div><!--grid_container-->
  <script>
                    function data(name,day_eng,day_rs,peek_eng,peek_rs,off_peek_eng,off_peek_rs)
                    {
                        var ceb=document.getElementById("therif_data");
                        if(ceb.style.display=="none")
                        {
                            ceb.style.display="block";
                            document.getElementById("clk_title").innerHTML=name;

                            document.getElementById("day_eng").innerHTML=day_eng;
                            document.getElementById("day_rs").innerHTML=day_rs;
                            document.getElementById("peek_eng").innerHTML=peek_eng;
                            document.getElementById("peek_rs").innerHTML=peek_rs;
                            document.getElementById("off_peek_eng").innerHTML=off_peek_eng;
                            document.getElementById("off_peek_rs").innerHTML=off_peek_rs;
                        }
                        else
                        {
                            ceb.style.display="none";
                        }
                    }
                    function close_q()
                    {
                        var ceb=document.getElementById("therif_data");
                        ceb.style.visivle="none";
                    }
                </script>         
  </main>
    <footer>
        <h4>devoloped by Hemas engineering team</h4>
    </footer>
  </body>
</html>
                
                