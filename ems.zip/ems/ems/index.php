<?php 
    include('inc/conn.php');
    session_start();
			
    function session_log($name,$email,$role)
    {
    	$_SESSION['name']=$name;
		$_SESSION['email']=$email;
		$_SESSION['role']=$role;
    }

	if (isset($_POST['submit'])) 
	{
			
		$error=[];
		if (!isset($_POST['email']) && (strlen(trim($_POST['email']))>=2)) 
		{
			$error[]="email does not suport/invalid";

		}
		else if (!isset($_POST['pass']) && (strlen(trim($_POST['pass']))>=2)) 
		{
			$error[]="password does not suport/invalid";
		} 

		if (empty($error)) 
		{
			$email=mysqli_escape_string($conn,$_POST['email']);
			$pass=mysqli_escape_string($conn,$_POST['pass']);
		
			$pass=sha1($pass);
			$pass=sha1($pass);
	
			$query="SELECT * FROM eee_usr_admin WHERE email= '{$email}' AND password= '{$pass}' LIMIT 1";
			$out=mysqli_query($conn,$query);
		
			if ($out && mysqli_num_rows($out)==1) 
			{
				$user=mysqli_fetch_assoc($out);
				session_log($user['name'],$user['email'],'admin');
				$date=date("Y-m-d H:i:s");
				$id=mysqli_escape_string($conn,$user['user_id']);
				$update="UPDATE eee_usr_admin SET last_log ='{$date}' WHERE user_id='{$id}'  LIMIT 1 ";
				if (mysqli_query($conn,$query))
				{
					header("Location:adm_home.php");
				}
				else
				{
					$error[]="connection error";
				}


			}
			else
			{


				$query="SELECT * FROM eee_usr_view WHERE email='{$email}' AND password='{$pass}' LIMIT 1";
			$out_view=mysqli_query($conn,$query);
			if ($out_view && mysqli_num_rows($out_view)==1) 
			{
				$user=mysqli_fetch_assoc($out_view);
				session_log($user['name'],$user['email'],'view');
				$update="UPDATE eee_usr_admin SET last_log ='{$date}' WHERE user_id='{$id}'  LIMIT 1 ";
				if (mysqli_query($conn,$query))
				{
					header("Location:view_home.php");
				}
				else
				{
					$error[]="connection error";
				}

			}
			else
			{
				$query="SELECT * FROM eee_usr_eng WHERE email='{$email}' AND password='{$pass}' LIMIT 1";
			$out=mysqli_query($conn,$query);
			if ($out && mysqli_num_rows($out)==1) 
			{
				$user=mysqli_fetch_assoc($out);
				session_log($user['name'],$user['email'],'eng');
				$update="UPDATE eee_usr_admin SET 'last_log'=date().now() WHERE 1 ";
				if (mysqli_query($conn,$query))
				{
					
				header("Location:eng_home.php");
				}
				else
				{
					$error[]="connection error";
				}


			}
			else
				{
					$error[]="username / password is incorrect ";
				}
			}
			}
		}
	}
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=	, initial-scale=1.0">
	<title>EMS-Hemas FMCG</title>
	<link rel="stylesheet" href="css/log.css">
	<link rel="stylesheet" href="css/util.css">
	<link rel="stylesheet" href="css/load.css">
</head>
<body class="log_body"  >
	
	<div class="left">
			<div class="limiter">
				<div class="container-login100">
						<div class="wrap-login100 p-t-85 p-b-20">
								<form class="login100-form validate-form" method="post" action="index.php">
											<span class="login100-form-title p-b-40">
												<i>
													Energy management system
												</i> 
										</span>
										<span class="login100-form-avatar">
												<img src="img/user.png" alt="AR">
										</span>
										<div id="error">
											
										<?php 
											if (!empty($error))
											{
												echo "<div class='error'> " .$error[0]. " </div>";
											}
										 ?>
										</div>

										
											
										<?php 
										
											if (!empty($_GET['log']))
											{
												echo "<div  style=' width: 100%; padding: 5%; margin-left: 10%; background-color: #57b846; color: white; background-opacity: 50%;
										50%' >";
												echo "successfully logout";
											}
										 ?>
										</div>
										<div class="wrap-input100 validate-input m-t-40 m-b-35" data-validate="Enter username">
												<input class="input100" type="email" name="email">
												<span class="focus-input100" data-placeholder="Username"></span>
										</div>

										<div class="wrap-input100 validate-input m-b-50" data-validate="Enter password">
												<input class="input100" type="password" name="pass">
												<span class="focus-input100" data-placeholder="Password"></span>
										</div>

										<div class="container-login100-form-btn">
												<button class="login100-form-btn" name='submit' type="submit">
														<b>Login Here</b>
												</button >
										</div>
										
								</form>
						</div>
				</div>
			</div>
	</div><!--left-->
	<div class="right">
		<img src="img/ems.jpg"  alt="AR0026image error">

	</div><!--right-->
	
			<div id="dropDownSelect1"></div>
				
				<script src="js/jquery-3.2.1.min.js.download"></script>
				
				<script src="js/animsition.min.js.download"></script>
				
				<script src="js/popper.js.download"></script>
				<script src="js/bootstrap.min.js.downloa"></script>
				
				<script src="js/select2.min.js.download"></script>
				
				<script src="js/moment.min.js.download "></script>
				<script src="js/daterangepicker.js.download "></script>
				
				<script src="js/countdowntime.js.download "></script>
				
				<script src="js/main.js.download "></script>
				
				<script async="" src="js/js"></script>
				<script>
	  				window.dataLayer = window.dataLayer || [];
	  				function gtag(){dataLayer.push(arguments);}
	  				gtag('js', new Date());
				
	  				gtag('config', 'UA-23581568-13');
				</script>
				<script defer="" src="./Login V6_files/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon="{&quot;rayId&quot;:&quot;747c14feeb9f41e2&quot;,&quot;token&quot;:&quot;cd0b4b3a733644fc843ef0b185f98241&quot;,&				quot;version&quot;:&quot;2022.8.1&quot;,&quot;si&quot;:100}" crossorigin="anonymous"></script>


	</body>
</html>


<div class="loader" id="loder">
  <div class="loader-spinner"></div>
</div>



<script>
    window.onload=function()
    {
    document.getElementById("loder").style.display="none";
    

   
    }
</script>