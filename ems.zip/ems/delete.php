<?php 
	include_once('inc/conn.php');
	print_r($_GET);
	if ($_GET['roll']=='eng') 
	{
		$query="DELETE FROM `eee_usr_eng` WHERE user_id={$_GET['id']} LIMIT 1";

		if (mysqli_query($conn,$query)) 
		{
			$header("Location:adm_home.php?out=deleted engineer");
		}
	}
	else if ($_GET['roll']=='admin') 
	{
				$query="DELETE FROM `eee_usr_admin` WHERE user_id={$_GET['id']} LIMIT 1";

		if (mysqli_query($conn,$query)) 
		{
			header("Location:adm_home.php?out=deleted admin");
		}
	}
	else if ($_GET['roll']=='viwer') 
	{
			echo "string";
		$query="DELETE FROM `eee_usr_view` WHERE user_id={$_GET['id']} LIMIT 1";
		if (mysqli_query($conn,$query)) 
		{
			header("Location:adm_profile.php?out=deleted");
		}
	}
 ?>