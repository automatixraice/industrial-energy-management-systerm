<?php 
	include_once('inc/adm_header.php');
?>
<div id="help">
<h1>
    Help
</h1>
<h3>email : anomatix@ar.lk</h3>
<h3>contact : 0703360146</h3>


</div>
