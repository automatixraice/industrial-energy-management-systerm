<?php 
	include_once('inc/adm_header.php');
	if (isset($_POST['update_user'])) {
		
		$error_up=[];

		if (isset($_POST['nm']) && (strlen(trim($_POST['nm']))<2))
		{
			$error_up[]="invalid Or missing name";
		}
	
		
		if (isset($_POST['phone']) && (strlen(trim($_POST['phone']))<2))
		{
			$error_up[]="invalid Or missing phone number";
		}

		if(empty($error_up))
		{
			$name=mysqli_escape_string($conn,$_POST['nm']);
			$phone=mysqli_escape_string($conn,$_POST['phone']);
			$department=mysqli_escape_string($conn,$_POST['roll']);
			$pass=mysqli_escape_string($conn,$_POST['pass_u']);
			$pass=sha1($pass);
			$pass=sha1($pass);
			if ($department=="eng")
			{

				$query="UPDATE `eee_usr_eng` SET `name`=[$name],`contact`='{$phone}',`password`={$pass}  WHERE user_id=9";
				if (!mysqli_query($conn,$query))
				{
					$error_up[]="error ";
				}
				else
				{
				echo"ccc";
				}

			}
			else if ($department=="view")
			{

				$query="UPDATE `eee_usr_view` SET `name`='{$name}',`contact`='{$phone}'  WHERE user_id=9";
				if (!mysqli_query($conn,$query))
				{
					$error_up[]="error ";
				echo "<script>alert('0000');</script>";
				}
				else
				{
				}

			}

		}
print_r($error_up);
	}

	if (isset($_POST['save_user']))
	{
		$error=[];

		if (isset($_POST['nm_c']) && (strlen(trim($_POST['nm_c']))<2))
		{
			$error[]="invalid Or missing name";
		}
	
		
		if (isset($_POST['roll_c']) && (strlen(trim($_POST['roll_c']))<2))
		{
			$error[]="invalid Or missing ROLL";
		}
		if (isset($_POST['phone_c']) && (strlen(trim($_POST['phone_c']))<2))
		{
			$error[]="invalid Or missing phone number";
		}

		if (isset($_POST['pass_c']) && (strlen(trim($_POST['pass_c']))<2))
		{
			$error[]="invalid Or missing password";
		}
		if (isset($_POST['mail_c']) && (strlen(trim($_POST['mail_c']))<2))
		{
			$error[]="invalid Or missing email ";
		}
		if (empty($error)) 
		{
			$name=mysqli_escape_string($conn,$_POST['nm_c']);
			$role=mysqli_escape_string($conn,$_POST['roll_c']);
			$contact=mysqli_escape_string($conn,$_POST['phone_c']);
			$email=mysqli_escape_string($conn,$_POST['email_c']);
			$pass=mysqli_escape_string($conn,$_POST['pass_c']);

					$pass=sha1($pass);
					$pass=sha1($pass);
			$finder_adm="SELECT * FROM eee_usr_admin WHERE email='{$email}' or password='{$pass}'  ";
			$finder_eng="SELECT * FROM eee_usr_eng WHERE email='{$email}' or password='{$pass}'  ";
			$finder_view="SELECT * FROM eee_usr_view WHERE email='{$email}' or password='{$pass}'  ";
			
						$finder_adm_query=mysqli_query($conn,$finder_adm);
						$finder_eng_query=mysqli_query($conn,$finder_eng);	
						$finder_view_query=mysqli_query($conn,$finder_view);	

			if ((mysqli_num_rows($finder_view_query)==0)&&(mysqli_num_rows($finder_eng_query)==0)&&(mysqli_num_rows($finder_adm_query)==0))
			{		
					
		
					if ($role=='admin') 
					{
						$query_insert="INSERT INTO `eee_usr_admin`( `name`, `email`, `contact`, `password`) VALUES ('{$name}','{$email}','{$contact}','{$pass}')";
		
					
						if (mysqli_query($conn,$query_insert)) 
							{
							}
						else
							{
								$error[]="calling error";
							}
					}
					else if ($role=='eng') 
					{
						$query_insert="INSERT INTO `eee_usr_eng`( `name`, `email`, `contact`, `password`) VALUES ('{$name}','{$email}','{$contact}','{$pass}')";
		
					
						if (mysqli_query($conn,$query_insert)) 
							{
								echo "done";
							}
						else
							{
							}
					}
					else
						{
							$query_insert="INSERT INTO `eee_usr_view`( `name`, `email`, `contact`, `password`) VALUES ('{$name}','{$email}','{$contact}','{$pass}');";
		
					
						if (mysqli_query($conn,$query_insert)) 
							{
							}
						else
							{
								$error[]="calling error view";
							}
						}

				
			}
			else
			{
				$error[]="user alrady inserted!";
			}
			
		}
	}


			if (!empty($error)) 
			{
					echo " <div id=\"error \" >$error[0] </div>";
				// code...
			}
			else if(isset($_POST['save_user']))
			{
				echo " <div id=\"btn btn-success \" >data inserted </div>";
			}



 ?>

	<h1>user list</h1>

	<table class="tbl_pfl" >
		<tr class="tbl_header">
			<th>Name</th>
			<th>Contact Number </th>
			<th>email</th>
			<th>department</th>
			<th>last log</th>
			<th></th>	
			<th></th>
		</tr>

	<?php 
	$adm_query="SELECT * FROM eee_usr_admin";
	$eng_query="SELECT * FROM eee_usr_eng";
	$view_query="SELECT * FROM eee_usr_view";

$out_adm=mysqli_query($conn,$adm_query);
$out_eng=mysqli_query($conn,$eng_query);
$out_view=mysqli_query($conn,$view_query);
if ($out_view) 
{
	for ($i=0; $i < mysqli_num_rows($out_view); $i++)
		{ 
				$user=mysqli_fetch_assoc($out_view);

			echo "<tr class='view'>";
			echo "<td id='amd'>{$user['name']}</td>";
			echo "<td >{$user['contact']}</td>";
			echo "<td>{$user['email']}</td>";
			echo "<td>viewer</td>";
			echo "<td>{$user['last_log']}</td>";			;
			echo "<td  id='delete'><a href='delete.php?id=\"{$user['user_id']}\"&&roll=viwer'> Delete</a></td>";
				echo "<td id='edite_btn' onclick=\"eee({$user['user_id']},'{$user['name']}','{$user['email']}','{$user['contact']}','view')\"><a > Edite</a></td>";
		echo "</tr>";
		}
}
if ($out_eng) 
{
	for ($i=0; $i < mysqli_num_rows($out_eng); $i++)
		{ 
				$user=mysqli_fetch_assoc($out_eng);

			echo "<tr class='eng'>";
			echo "<td id='amd'>{$user['name']}</td>";
			echo "<td >{$user['contact']}</td>";
			echo "<td>{$user['email']}</td>";
			echo "<td>eng</td>";
			echo "<td>{$user['last_log']}</td>";			;
						echo "<td  id='delete'><a href='delete.php?id=\"{$user['user_id']}\"&&roll=eng'> Delete</a></td>";
			echo "<td id='edite_btn' onclick=\"eee({$user['user_id']},'{$user['name']}','{$user['email']}','{$user['contact']}','eng')\"><a > Edite</a></td>";
			#id,name,mail,number,department
		echo "</tr>";
		}
}
if ($out_adm) 
{
	for ($i=0; $i < mysqli_num_rows($out_adm); $i++)
		{ 
				$user=mysqli_fetch_assoc($out_adm);

			echo "<tr class='admin'>";
			echo "<td id='amd'>{$user['name']}</td>";
			echo "<td >{$user['contact']}</td>";
			echo "<td>{$user['email']}</td>";
			echo "<td>admin</td>";
			echo "<td>{$user['last_log']}</td>";			;
			
		echo "</tr>";
		}
}
/*	if (($out_adm)&&($out_eng) && ($out_view)) 
	{
		$eng=mysqli_fetch_assoc($out_eng);
		echo $eng['name'];
		$view=mysqli_fetch_assoc($out_view);
		
		function data_show($data,$role)
		{
			for ($i=0; $i < mysqli_num_rows($data); $i++)
		{ 
				$user=mysqli_fetch_assoc($data);

			echo "<tr class='$role'>";
			echo "<td id='amd'>{$user['name']}</td>";
			echo "<td >{$user['contact']}</td>";
			echo "<td>{$user['email']}</td>";
			echo "<td>{$role}</td>";
			echo "<td>{$user['last_log']}</td>";			;
			echo "<td  id='delete'><a href='/adm/usr/delete?id={{adm.user_id}}&&roll=admin'> Delete</a></td>";
			echo "<td id='edite_btn' onclick='eee({{adm.user_id}},'{{adm.name}}','{{adm.email}}','{{adm.contact}}','admin')'><a > Edite</a></td>";
		echo "</tr>";
		}
		}
		data_show($out_adm,'admin');
		data_show($out_view,'view');
		#data_show($out_eng,'eng');

	}*/

	 ?>
	



	</table>

<div class="edite" id="edite" >
            <div class="modal-content ">
    <div class="frm_head">
    <span class="info  ">  profile edit </span>
    <span class="close" id="close" >&times;</span>
        
    </div>
  
    <center>    <p class="display-3 title bg-info">Edite Your profile</p></center>
      <form class="well form-horizontal"  method="post"   id="contact_form" action="adm_profile.php" name="add_itm">
      
      <fieldset>

<!-- Text input-->
<div class="form-group">

  <label class="col-md-112 control-label">Name of user</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input   class="nmb" name="id" type="text" id="nmb"   />
			<input   class="form-control" name="nm" type="text" id="nm"   />
    </div>
<div class="form-group">
  <label class="col-md-112 control-label">Department</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input   class="form-control" name="roll" type="text" id="department"   />
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-112 control-label">E-mail Address</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input  name="email" class="form-control"   id="mail" type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-112 control-label">Contact number</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input  name="phone" id="number" class="form-control"    type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-112 control-label">password</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
    <input  name="pass_u" id="pass" class="form-control"    type="text">

    </div>
  </div>
</div>
  
<!-- Button -->
<div class="form-group">
  <label class="col-md-12 control-label"></label>
  <div class="col-md-12"><br>
  
    <button type="submit" class="btn btn-success" name="update_user"  id="update">  
    Update
 
</button>

  </div>
</div>

</fieldset>
</form>
</div></div>



<!--*********************************************************************************************************************************************************************************************************************************************************************** *********************************************************************************************************************************************************- -->

<span class="add_user" id="add_user" onclick="add_user()">

		+ add user

</span>

<div class="add_usr" id="add" >
    <div class="modal-content">
    <center>    
    	<p class="display-3 title bg-info">Add a new User</p>
  </center>
      <form class="well form-horizontal"  method="post"   id="contact_form" action="adm_profile.php" name="add_itm">
      <fieldset>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-112 control-label">Name of user</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input   class="form-control" placeholder="name" name="nm_c" type="text" id="nm_c"  onchange ="validate('nm_c')" />

    </div>

<div class="form-group">
  <label class="col-md-112 control-label">Department</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<select class="form-control"name="roll_c" id="department">
				<option value="view">view</option>
				<option value="eng">eng	</option>
				<option value="admin">admin</option>
			</select>
    </div>
   
  </div>
</div>
<div class="form-group">
  <label class="col-md-112 control-label">email Address</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input  name="email_c" placeholder="email_c" class="form-control"   id="mail_c" type="mail" onchange ="validate('mail_c')">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-112 control-label">Contact number</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input  name="phone_c" id="number_c" placeholder="000 0000 0000" class="form-control"    type="tel" onchange ="validate('number_c')" >
    </div>
  </div>
</div>

<div class="form-group">
  <label class="col-md-112 control-label">password</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group" id="passwred">
	<div class="genarate btn btn-danger" onclick="gen()" >Genarate</div>
  <input  name="pass_c" id="pass_c"  class="form-control"    type="text" onchange ="validate('pass_c')" >
    </div>
  </div>
</div>
  
<!-- Button -->
<div class="form-group">
  <label class="col-md-12 control-label"></label>
   
    <button type="submit" class="btn btn-save" name="save_user"  id="save">  
    save
 
</button>

<button  class="btn btn-gray" name="save_user"  id="save" onclick="close()">  
    cancel
 
</button>

  </div>
</div>


</fieldset>
</form>
</div></div>
<script>
	function gen()
	{
		var text=document.getElementById('pass_c');
		var chars = "0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		var passwordLength = 14;
 		var password = "";
  	for (var i = 0; i <= passwordLength; i++) 
  	{

  	 	var randomNumber = Math.floor(Math.random() * chars.length);
  	 	password += chars.substring(randomNumber, randomNumber +1);
  	}
  	text.value = password;


	}
	var close=document.getElementById('close');
	close.onclick=function()
	{
		panel.style.display='none';
	};			
	function eee(id,name,mail,number,department)
		{
			var model=document.getElementById("edite_btn");
			var panel=document.getElementById('edite');
			var panel_user=document.getElementById("add_user");
			if (panel.style.display=="none") 
					{
						panel.style.display = "block";
						panel_user.style.display = "none";
								document.getElementById("nm").value=name;
								document.getElementById("nmb").value=id;
								document.getElementById("mail").value=mail;
								document.getElementById("number").value=number;
								document.getElementById("department").value=department;
					}
					else
					{
						panel.style.display = "none";
						panel_user.style.display = "block";

					}								
					}
var btn_add=document.getElementById("add_user");

function add_user()
{
	var panel=document.getElementById('edite');
	var panel_add=document.getElementById('add');
	panel.style.display="none";
	panel_add.style.display="block";
	
}

function close()
{
	var panel=document.getElementById('edite');
	var panel_add=document.getElementById('add');
	panel.style.display="none";
	panel_add.style.display="none";
}

function validate(input)
{
	var val=document.getElementById(input).value;
	var save_btn=document.getElementById('save');
	if (val.length<6)
	{

		document.getElementById(input).style.border="1px solid red";
		document.getElementById('save').style.display="none";

	}
	else
	{

		document.getElementById(input).style.border="#fff";
		document.getElementById('save').style.display="inline-block";

	}

}
</script>	
