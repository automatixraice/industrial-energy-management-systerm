$(".menu-toggle-btn").click(function(){
  $(this).toggleClass("fa-times");
  $(".navigation-menu").toggleClass("active");

  alert("tttt");
  $(".title").style.visibility="hidden";
});
