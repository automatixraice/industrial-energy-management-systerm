
<?php 
  session_start();
  include('conn.php');
    if (!isset($_SESSION['name']))
    {
      header("Location:index.php");
      session_destroy();
    }
 ?>

 <!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Hemas manufacture | EMS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" charset="utf-8"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/analizer.css">
    <link rel="stylesheet" href="css/profile.css">
  </head>
  <body>
    <script src="js/main.css"></script>
    <header>
      <div class="inner-width">
        <h1 class="logo"><img src="logo.png" alt="not show"><span style="color:#273b91;"></span></h1>

        <i class="menu-toggle-btn fas fa-bars"></i>
        <nav class="navigation-menu">
          <h1 class="title">Energy monitoring system  </h1>
          <a href="adm_home.php"><i class="fas fa-home"></i> Dashbord</a>
          <a href="adm_analizer.php"><i class="fas fa-val"></i> analizer</a>
          <a href="adm_history.php"><i class="fas fa-history"></i> histoty</a>
          <a href="adm_profile.php"><i class="fas fa-user"></i> profiles</a>
          <a href="adm_help.php"><i class="fas fa-help"></i> Help</a>
          <a href="logout.php" class="aj_btn"> <i class="fas fa-lock" aria-hidden="true"></i>
            Logout
          </a>
        </nav>
      </div>
    </header>

    <script type="text/javascript" src="js/main.js"></script>
  
