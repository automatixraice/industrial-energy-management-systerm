<?php 
    include('inc/adm_header.php');
 		date_default_timezone_set("Asia/Colombo");
 ?>

 

	<table class="tbl_anlz">	
		<tr class="tbl_header ">
			<td>id</td>
			<td>name</td>
			<td>value</td>
			<td>plant</td>
		</tr>

			<?php 	

												
					if (date("H")<18 &&(date("H")>5)) 
					{
												$query="SELECT * FROM value WHERE _id=(SELECT MAX(_id) FROM value LIMIT 1 )";

					}
					elseif (date("H")<22 && (date("H")>18))
					 {
						$query="SELECT * FROM valuepeek WHERE _id=(SELECT MAX(_id) FROM valuepeek LIMIT 1 )";
						
					}

						$query="SELECT * FROM value WHERE _id=(SELECT MAX(_id) FROM value LIMIT 1 )";
						$out=mysqli_query($conn,$query);
						
						if(!$out)
						{
							echo "Error has ocurred!";

						}
						else
						{
									$data=mysqli_fetch_assoc($out);
									$e2=$data['e2'];
									$e3=$data['e3'];
									$e4=$data['e4'];
									$e5=$data['e5'];
									$e6=$data['e6'];
									$e7=$data['e7'];
									$e8=$data['e8'];
									$e9=$data['e9'];
									$e10=$data['e10'];
									$e11=$data['e11'];
									$e12=$data['e12'];
									$e13=$data['e13'];
									$e14=$data['e14'];
		
								
									echo " <div class=\" admin_last_update \"> Last Update : {$data['_dbTime']}</div>";
									$complex=['FURFUME ROOM','OFFICE END','DB OFFICE','DB AC','DB UPS ','FAN'];
									$plants=['pc','Soap','napkin','complex','stores'];
									$store=['STORES GROUND ','STORES GROUND ','STORES UPPER FLOOR','STORES OFFICE','GOOD HOIST','GOOD HOIST(FB)','GOOD HOIST(RM)','GOOD HOIST(TALK)'];

									for ($i=2; $i <=7; $i++)
							 		{ 

										echo "<tr class=\"day_analizer\">";
										echo "<td>".($i-1)."</td>";
										echo "<td>{$complex[($i-2)]}</td>";
										echo "<td>${"e".$i}</td>";
										echo "<td>{$plants[3]}</td>";
										echo "</tr>";
									}

									for ($i=9; $i <=14; $i++)
							 		{ 

										echo "<tr class=\"peek_analizer\">";
										echo "<td>".($i-1)."</td>";
										echo "<td>{$store[($i-9)]}</td>";
										echo "<td>${"e".$i}</td>";
										echo "<td>{$plants[4]}</td>";
										echo "</tr>";
		
									}
						}
			 ?>



		
	</table>	
	


<div class="edite" id="edite" >
            <div class="modal-content ">
    <div class="frm_head">
    <span class="info  ">  profile edite </span>
    <span class="close" id="close" >&times;</span>
        
    </div>
  
    <center>    <p class="display-3 title bg-info">Edite Your profile</p></center>
      <form class="well form-horizontal"  method="post"   id="contact_form" action="/adm/edite/analyzer/" name="add_itm">
      	{% csrf_token %}
      <fieldset>
<!-- Text input-->
<div class="form-group">
  <label class="col-md-112 control-label">Name of analizer</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input   class="nmb" name="id" type="text" id="nmb"   />
			<input   class="form-control" name="nm" type="text" id="nm"/>
    </div>
<!-- Button -->
<div class="form-group">
  <label class="col-md-12 control-label"></label>
  <div class="col-md-12"><br>
    <button type="submit" class="btn btn-success" name="update_user"  id="update">  
    	Update
	</button>
  </div>
</div>
</fieldset>
</form>
</div>
</div>
</fieldset></form>
</div>
</div>
</div>
</main>
</body>
</html>
    
<script>
	function eee(id,value,time,p_number,a_nmb)
		{
			var model=document.getElementById("edite_btn");
			var panel=document.getElementById('edite');
			var panel_user=document.getElementById("add_user");
			if (panel.style.display=="none") 
					{
						panel.style.display = "block";
    					document.getElementById("nm").value="12";
    					alert("z");
						document.getElementById("nm").value="alynz 1";
						document.getElementById("nmb").value=id;
						alert(p_number)
					}
					else
					{
						panel.style.display = "none";
						panel_user.style.display = "block";
					}								
					}
</script>
	{% endblock %}