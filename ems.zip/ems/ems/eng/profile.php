
	{% extends 'adm/base.html' %}

	{% block content %}
	<?php 
		$conn=mysqli('localhost','root','','root');

		mysqli_connect();
		$query="SELECT * FROM  admin"
	 ?>
	
	<h1>user list</h1>

	<table class="tbl_pfl" >
		<tr class="tbl_header">
			<th>id</th>
			<th>name</th>
			<th>Contact Number </th>
			<th>email</th>
			<th>department</th>
			<th>last log</th>
			<th></th>	
			<th></th>
		</tr>
		{% for adm in admin %}
		<tr class="admin">
			<td id="id">{{adm.user_id}}</td>
			<td id="name">{{adm.name}}</td>
			<td >{{adm.contact}}</td>
			<td>{{adm.email}}</td>
			<td>Admin</td>
			<td>{{adm.last_log}}</td>			
			<td  id="delete"><a href="/adm/usr/delete?id={{adm.user_id}}&&roll=admin"> Delete</a></td>
			<td id="edite_btn" onclick="eee({{adm.user_id}},'{{adm.name}}','{{adm.email}}','{{adm.contact}}','admin')"><a > Edite</a></td>
		</tr>
		{% endfor %}
		{% for eng in eng %}
		<tr class="eng">
			<td>{{eng.user_id}}</td>
			<td>{{eng.name}}</td>
			<td>{{eng.contact}}</td>
			<td>{{eng.email}}</td>
			<td>engineer</td>
			<td>{{eng.last_log}}</td>	
			
			<td  id="delete"><a href="/adm/usr/delete?id={{eng.user_id}}&&roll=eng"> Delete</a></td>
			<td id="edite_btn" onclick="eee({{eng.user_id}},'{{eng.name}}','{{eng.email}}','{{eng.contact}}','eng')"><a > Edite</a></td>

		</tr>
		{% endfor %}
		{% for view in view %}
		<tr class="view">
			<td>{{view.user_id}}</td>
			<td>{{view.name}}</td>
			<td>{{view.contact}}</td>
			<td>{{view.email}}</td>
			<td>viewer</td>
			<td>{{view.last_log}}</td>

						<td  id="delete"><a href="/adm/usr/delete?id={{view.user_id}}&&roll=view"> Delete</a></td>
						<td id="edite_btn" onclick="eee({{view.user_id}},'{{view.name}}','{{view.email}}','{{view.contact}}','viewer')"><a > Edite</a></td>



		</tr>
		{% endfor %}


	</table>

<div class="edite" id="edite" >
            <div class="modal-content ">
    <div class="frm_head">
    <span class="info  ">  profile edite </span>
    <span class="close" id="close" >&times;</span>
        
    </div>
  
    <center>    <p class="display-3 title bg-info">Edite Your profile</p></center>
      <form class="well form-horizontal"  method="post"   id="contact_form" action="/adm/process/" name="add_itm">
      	{% csrf_token %}
      <fieldset>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-112 control-label">Name of user</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input   class="nmb" name="id" type="text" id="nmb"   />
			<input   class="form-control" name="nm" type="text" id="nm"   />
    </div>
<div class="form-group">
  <label class="col-md-112 control-label">Department</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input   class="form-control" name="roll" type="text" id="department"   />
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-112 control-label">E-mail Address</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input  name="email" class="form-control"   id="mail" type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-112 control-label">Contact number</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input  name="phone" id="number" class="form-control"    type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-112 control-label">password</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <label class="btn btn-danger " onclick="reset()">
      Reset password
  </label>
    </div>
  </div>
</div>
  
<!-- Button -->
<div class="form-group">
  <label class="col-md-12 control-label"></label>
  <div class="col-md-12"><br>
  
    <button type="submit" class="btn btn-success" name="update_user"  id="update">  
    Update
 
</button>

  </div>
</div>

</fieldset>
</form>
</div></div>



<!--*********************************************************************************************************************************************************************************************************************************************************************** *********************************************************************************************************************************************************- -->

<span class="add_user" id="add_user" onclick="add_user()">

		+ add user

</span>

<div class="add_usr" id="add" >
    <div class="modal-content ">
    <center>    <p class="display-3 title bg-info">Add a new User</p></center>
      <form class="well form-horizontal"  method="post"   id="contact_form" action="/adm/add_user/" name="add_itm">
      	{% csrf_token %}
      <fieldset>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-112 control-label">Name of user</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input   class="form-control" placeholder="name" name="nm" type="text" id="nm"   />

    </div>

<div class="form-group">
  <label class="col-md-112 control-label">Department</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<select class="form-control"name="roll" id="department">
				<option value="view">view</option>
				<option value="eng">eng	</option>
				<option value="admin">admin</option>
			</select>
    </div>
   
  </div>
</div>
<div class="form-group">
  <label class="col-md-112 control-label">email Address</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input  name="email" placeholder="email" class="form-control"   id="mail" type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-112 control-label">Contact number</label>  
  <div class="col-md-12 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input  name="phone" id="number" placeholder="000 0000 0000" class="form-control"    type="text">
    </div>
  </div>
</div>
  
<!-- Button -->
<div class="form-group">
  <label class="col-md-12 control-label"></label>
   
    <button type="submit" class="btn btn-save" name="save_user"  id="save">  
    save
 
</button>

<button type="submit" class="btn btn-gray" name="save_user"  id="save">  
    cancel
 
</button>

  </div>
</div>


</fieldset>
</form>
</div></div>
<script>
	
	var close=document.getElementById('close');
	close.onclick=function()
	{
		panel.style.display='none';
	};			
	function eee(id,name,mail,number,department)
		{
			var model=document.getElementById("edite_btn");
			var panel=document.getElementById('edite');
			var panel_user=document.getElementById("add_user");
			if (panel.style.display=="none") 
					{
						panel.style.display = "block";
						panel_user.style.display = "none";
								document.getElementById("nm").value=name;
								document.getElementById("nmb").value=id;
								document.getElementById("mail").value=mail;
								document.getElementById("number").value=number;
								document.getElementById("department").value=department;
					}
					else
					{
						panel.style.display = "none";
						panel_user.style.display = "block";

					}								
					}
var btn_add=document.getElementById("add_user");

function add_user()
{
	var panel=document.getElementById('edite');
	var panel_add=document.getElementById('add');
	panel.style.display="none";
	panel_add.style.display="block";
	alert("s");
	
}
</script>	
{% endblock %}