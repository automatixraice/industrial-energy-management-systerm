<?php 
    include_once('inc/adm_header.php');
    

 ?>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<div id="myChart" style="width:50%;  height:500px;float: right;"></div>
<div id="myChart2" style="width:50%;  height:500px;float: left;"></div>
<script>
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
var data = google.visualization.arrayToDataTable([
  ['energy', 'KWh'],
  ['plant 1',14.8],
  ['plant 2',54.8],
  ['plant 3',48.6],
  ['complex',28.6],
  ['other',42.6],
]);

var data2 = google.visualization.arrayToDataTable([
  ['energy', 'KWh'],
  ['CEB',42.8],
  ['Geenaretor',12.8],

]);

var options = {
  title:'usage',
};

var chart = new google.visualization.PieChart(document.getElementById('myChart'));
var chart2 = new google.visualization.PieChart(document.getElementById('myChart2'));
  chart.draw(data, options);
  chart2.draw(data2, options);
}
</script>

  